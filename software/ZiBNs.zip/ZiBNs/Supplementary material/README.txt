###################################################################################
============================= SUPPLEMENTARY MATERIAL ==============================
###################################################################################

TO VISUALIZE THE BAYESIAN NETWORK STRUCTURE, YOU MUST OPEN THE ".elv" FILES WITH "Elvira.jar" (DOWNLOAD AVAILABLE AT www.ia.uned.es/~fjdiez/bayes/elvira/instalar/install.html).

TO DEPICT THE SPECIES OCCURRENCE MAPS, COPY THE PROBABILITIES  FROM THE “[…]presence.csv” FILES INTO THE “CUTM.csv” FILE. THIS IS THE LABEL TO GEOREFERENCE THE DATA. THE “Study area” FOLDER CONTAINS THE GEOREFERENCED LOCATION (main file extension: .shp). THE PROBABILITIES CAN BE JOINED TO THE MAP THROUGH THE COMMON LABEL BY USING ANY GEOGRAPHIC INFORMATION SYSTEMs.
