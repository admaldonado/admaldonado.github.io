#################################### README #####################################
#################################################################################

BEFORE STARTING THE EXPERIMENTS, MAKE SURE YOU HAVE Java INSTALLED ON YOUR SYSTEM.
If you are not sure, you can check it by typing “java -version” (without quotation marks) into the command-line terminal.

#################################################################################
THE FOLDER ZiBNs CONTAINS: 

1. elvira.zip —> the software containing the code. 
2. Example.r—> the script to run the software.

3. Eagle.dbc —> the COMPLETE dataset for the example “Eagle”.
4. EagleTest.dbc —> the TEST dataset for the example “Eagle”.
5. EagleTrain.dbc —> the TRAIN dataset for the example “Eagle”.

6. EagleZi.dbc —> the COMPLETE dataset for “Eagle”, including artificial variables.
7. EagleZiTest.dbc —> the TEST dataset for “Eagle”, including artificial variables.
8. EagleZiTrain.dbc —> the TRAIN dataset for “Eagle”, including artificial variables.

9. Salamander.dbc —> the COMPLETE dataset for the example “Salamander”.
10. SalamanderTest.dbc —> the TEST dataset for the example “Salamander”.
11. SalamanderTrain.dbc —> the TRAIN dataset for the example “Salamander”.

12. SalamanderZi.dbc —> the COMPLETE dataset for “Salamander”, including artificial variables.
13. SalamanderZiTest.dbc —> the TEST dataset for “Salamander”, including artificial variables.
14. SalamanderZiTrain.dbc —> the TRAIN dataset for “Salamander”, including artificial variables.

15. this README.txt


##################################################################################
FOLLOW THESE INSTRUCTIONS TO USE THE SOFTWARE.

1. Open your computer’s command-line Terminal.
2. Set the working directory in the Terminal by typing “cd” (without quotation marks), press the spacebar afterwards, and dragging the ZiBNs folder into the terminal. Press the enter key.
3. Unzip the elvira.zip file by using the command: “unzip elvira.zip” (without quotation marks). Press the enter key.
4. Run the Example.r file by using the command: “./Example.r” (without quotation marks). Press the enter key.

Approximately, the experiments will take 90 minutes to finish (or 10 minutes if cross validation is excluded from the script).


###################################################################################
DESCRIPTION OF THE Example.r FILE

The Example.r file specifies the arguments for the algorithms used in the paper “Modeling zero-inflated explanatory variables in hybrid Bayesian network classifiers for species occurrence prediction”.

The arguments for each algorithm are as follows:

** ZeroInflatedTANMTEClassifier ** Main for constructing a ZiTAN Classifier
1. the dbc Train file
2. the dbc ZiTrain file
3. the index of the class variable
4. the number of intervals
5. the index of the first zero-inflated variable
6. the index of the last zero-inflated variable
7. the seed
8. the dbc ZiTest file or CV in the case of k-fold cross-validation
9. the name given to the network or the number of folds in the case of cross-validation
NOTE that when CV is chosen, k-measures of accuracy are obtained instead of the file network.elv


** TANMTEClassifier ** Main for constructing a TAN Classifier
1. the dbc Train file
2. the dbc Test file or CV in the case of k-fold cross-validation
3. the index of the class variable
4. the number of intervals
5. the seed
6. the name given to the network or the number of folds in the case of cross-validation
NOTE that when CV is chosen, k-measures of accuracy are obtained instead of the file network.elv


** Bnet ** Main for constructing a confusion matrix
1. the elv file
2. the dbc (Zi)test file
3. the name of the class variable as it is written in the dbc file


** PresenceTANMTEClassifier ** Main for predicting the probability of presence of a given species
1. the elv file
2. the dbc file (COMPLETE dataset)
3. the index of the class variable
4. the number of intervals
5. the name given to the csv file



##################################################################################
ONCE THE EXPERIMENTS ARE DONE, YOU WILL HAVE OBTAINED THE FOLLOWING FILES:

1. SalamanderZiTANClassifier.elv —> the zero-inflated TAN model for Salamander.
2. SalZiTAN_CV.txt —> the results of the 10-fold cross validation.
3. SalZiTAN_CM.txt —> the confusion matrix obtained from the ZiTAN model for Salamander.
4. SalZiTAN_presence.csv —> the probability of presence of Salamander obtained from the ZiTAN model.

5. SalamanderTANClassifier.elv —> the TAN model for Salamander.
6. SalTAN_CV.txt —> the results of the 10-fold cross validation.
7. SalTAN_CM.txt —> the confusion matrix obtained from the TAN model for Salamander.
8. SalTAN_presence.csv —> the probability of presence of Salamander obtained from the TAN model.


9. EagleZiTANClassifier.elv —> the zero-inflated TAN model for Eagle.
10. EagZiTAN_CV.txt —> the results of the 10-fold cross validation.
11. EagZiTAN_CM.txt —> the confusion matrix obtained from the ZiTAN model for Eagle.
12. EagZiTAN_presence.csv —> the probability of presence of Eagle obtained from the ZiTAN model.

13. EagleTANClassifier.elv —> the TAN model for Eagle.
14. EagZiTAN_CV.txt —> the results of the 10-fold cross validation.
15. EagTAN_CM.txt —> the confusion matrix obtained from the TAN model for Eagle.
16. EagTAN_presence.csv —> the probability of presence of Eagle obtained from the TAN model.


###################################################################################
###################################################################################
============================= SUPPLEMENTARY MATERIAL ==============================
###################################################################################

TO VISUALIZE THE BAYESIAN NETWORK STRUCTURE, YOU MUST OPEN THE ".elv" FILES WITH "Elvira.jar" (DOWNLOAD AVAILABLE AT www.ia.uned.es/~fjdiez/bayes/elvira/instalar/install.html).

TO DEPICT THE SPECIES OCCURRENCE MAPS, COPY THE PROBABILITIES  FROM THE “[…]presence.csv” FILES INTO THE “CUTM.csv” FILE IN THE “Supplementary material” FOLDER. THIS IS THE LABEL TO GEOREFERENCE THE DATA. THE “Study area” FOLDER CONTAINS THE GEOREFERENCED LOCATION (main file extension: .shp). THE PROBABILITIES CAN BE JOINED TO THE MAP BY USING ANY GEOGRAPHIC INFORMATION SYSTEMs.
