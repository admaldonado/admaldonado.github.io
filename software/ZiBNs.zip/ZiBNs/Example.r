java elvira/learning/classification/supervised/mixed/ZeroInflatedTANMTEClassifier SalamanderTrain.dbc SalamanderZiTrain.dbc 14 3 7 20 50 SalamanderZiTest.dbc Salamander 
java elvira/Bnet SalamanderZiTANClassifier.elv SalamanderZiTest.dbc Salamander > SalZiTAN_CM.txt
java elvira/learning/classification/supervised/mixed/TANMTEClassifier SalamanderTrain.dbc SalamanderTest.dbc 14 3 50 Salamander  
java elvira/Bnet SalamanderTANClassifier.elv SalamanderTest.dbc Salamander > SalTAN_CM.txt
java elvira/learning/classification/supervised/mixed/PresenceTANMTEClassifier SalamanderZiTANClassifier.elv SalamanderZi.dbc 21 3 SalZiTAN_presence.csv
java elvira/learning/classification/supervised/mixed/PresenceTANMTEClassifier SalamanderTANClassifier.elv Salamander.dbc 14 3 SalTAN_presence.csv
java elvira/learning/classification/supervised/mixed/ZeroInflatedTANMTEClassifier EagleTrain.dbc EagleZiTrain.dbc 15 3 5 24 50 EagleZiTest.dbc Eagle
java elvira/Bnet EagleZiTANClassifier.elv EagleZiTest.dbc Eagle > EagZiTAN_CM.txt
java elvira/learning/classification/supervised/mixed/TANMTEClassifier EagleTrain.dbc EagleTest.dbc 15 3 50 Eagle  
java elvira/Bnet EagleTANClassifier.elv EagleTest.dbc Eagle > EagTAN_CM.txt
java elvira/learning/classification/supervised/mixed/PresenceTANMTEClassifier EagleZiTANClassifier.elv EagleZi.dbc 25 3 EagZiTAN_presence.csv
java elvira/learning/classification/supervised/mixed/PresenceTANMTEClassifier EagleTANClassifier.elv Eagle.dbc 15 3 EagTAN_presence.csv
java elvira/learning/classification/supervised/mixed/ZeroInflatedTANMTEClassifier SalamanderTrain.dbc SalamanderZiTrain.dbc 14 3 7 20 50 CV 10 > SalZiTAN_CV.txt
java elvira/learning/classification/supervised/mixed/TANMTEClassifier SalamanderTrain.dbc CV 14 3 50 10 > SalTAN_CV.txt
java elvira/learning/classification/supervised/mixed/ZeroInflatedTANMTEClassifier EagleTrain.dbc EagleZiTrain.dbc 15 3 5 24 50 CV 10 > EagZiTAN_CV.txt
java elvira/learning/classification/supervised/mixed/TANMTEClassifier EagleTrain.dbc CV 15 3 50 10  > EagTAN_CV.txt